library(shiny)    # should include this at the start of apps that call shiny-specific functions

d <- read.csv("subctr_60_data.csv")    # read in data


shinyServer(function(input, output) {

  # (1) CREATE AN OBJECT THAT RESPONDS TO USER INPUT
  options = reactiveValues(choose="allemp97")   # creates the object 'options'
  # creates an event based on an input, then passes it to the object 'options$choose'
  observeEvent(input$go, {
    # a handy way to convert user-friendly input values to data-friendly strings (i.e., column names!)
    name_link = switch(input$variable, "KIBS"="kibsemp", "Retail"="retemp", "Creative"="crtvemp", "Industrial"="indemp", 
                       "High Tech"="techemp", "All"="allemp")
    # pastes name link with the last two digits of the year - options$choose is now the column name the user has selected 
    options$choose = paste(name_link, substr(input$year,3,4), sep="")
  })
  
  # (2) USE THAT OBJECT (WHICH IS THE NAME OF THE USER-SELECTED COLUMN) TO MAKE 3 OUTPUTS (PLOT AND TWO PRINTS)
  observeEvent(input$go,{
    # object 'choice' is the vector of data the user has selected
    choice = d[,grep(options$choose, colnames(d))]
    # renders a histogram, and passes it to the object 'output$hist'
    output$hist <- renderPlot({
      # an R histogram of 'choice' with several parameters for labels, titles, breaks, and colors
      hist(choice, xlab=NULL, breaks=12, col="dodgerblue",
           ylab="# of Cities", border="white", main=paste(input$year, input$variable, "Employment", sep=" "))
      # adds a vertical guideline equal to the selected city's value
      abline(v=choice[d$subctrNAME==input$city], lwd=2) 
      # adds a dotted vertical guideline equal to the mean value
      abline(v=mean(choice, na.rm=T), lty=2)
      # adds a legend with two items to the top right 
      legend("topright", c(input$city, "Avg of Cities"), lwd=c(2,1), lty=c(1,2), box.col="white")
    })
    # renders some descriptive statistics based on the city chosen
    output$data1 <- renderPrint({
      paste(input$city, input$variable, input$year, ":", choice[d$subctrNAME==input$city],
            "(", round(ecdf(choice[!is.na(choice)])(choice[d$subctrNAME==input$city]),4), "percentile)")
    })
    # renders some descriptive statistics based on the variable chosen
    output$data2 <- renderPrint({
      summary(choice)
    })
  })

    # (3) CREATE TEXT OUTPUT BASED ON THE DATA FRAME 'descr' BASED ON USER'S VARIABLE CHOICE
    output$var_desc <- renderText({
      # switches 'input$variable' to another string which contains a description. 
      data_link = switch(input$variable,
                       "KIBS" = "stands for Knowledge-Intensive Business Services.",
                       "Retail"= "employment is currently selected.",
                       "Creative"= "employment consists of arts, entertainment, recreation, and information.",
                       "Industrial"= "employment includes manufacturing and utilities.",
                       "High Tech"= "employment spans several industries and includes tech manufacturing.",
                       "All"= "employment is currently selected.")
      paste(input$variable, data_link)
    })
})  

