library(shiny)

d <- read.csv("subctr_60_data.csv")
names <- as.character(unique(unlist(d$subctrNAME)))

# this UI layout has a titlePanel across the top, a sidebarPanel on the left, and a mainPanel for content - each surround their contents with parentheses. 
shinyUI(fluidPage(
  titlePanel(strong("SoCal Employment Center Stats")),
  sidebarLayout(
    sidebarPanel(
      h5(strong("Choose Employment Type:")),   # header type #5 is used here along with boldface (strong)
      selectInput("variable", label=NULL,
                  choices=list("", "KIBS", "Retail", "Creative", "Industrial", "High Tech", "All"), selected="All"),
      h5(strong("Choose Year:")),
      selectInput("year", label=NULL,
                  choices=list("", "1997", "2014"), selected="1997"),
      h5(strong("Choose Employment Center:")),
      # an input which pulls its choices from a cleaned-up list of city names from the object d, which is the input data
      selectInput("city", label=NULL, choices = names[order(names)], selected="Irvine/SNA"),
      actionButton("go", label="Go/Refresh"),  # an input item that can be used with observeEvent
      br(),   # add a line break
      p(strong("Data Notes:")),
      textOutput("var_desc"),
      br(),
      # include a link using href
      a("the Metropolitan Futures Initiative", href="http://mfi.soceco.uci.edu"),
      # include an image. images must be stored in a subfolder of the app's directory called 'www'
      img(src="mfi.jpg", height=200, width=200)
    ),
    mainPanel(
      h2("Employment Centers in Southern California"),
      p(em("Employment totals by center are displayed below. ")),   #em is used for italics
      plotOutput("hist", height = 400),   
      textOutput("data1"),   # verbatimTextOutput keeps text output formatted properly 
      verbatimTextOutput("data2")
    )
  )
))