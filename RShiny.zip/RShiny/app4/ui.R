# Web map for displaying proximity of services to schools - Long Beach, CA
# K. Kane, January 2017

library(shiny)
library(leaflet)

all <- read.csv("LBplus1mi_RefUSA_2014.csv", stringsAsFactors = F)

shinyUI(tabPanel("What's near your child's elementary school?", div(class="outer",
        tags$head(includeCSS("styles.css")),
        leafletOutput("myMap", width="100%", height="100%"),
        absolutePanel(id="controls", class="panel panel-default", fixed=TRUE, 
                      draggable=TRUE, top=60, left="auto", right=20, bottom="auto",
                      width=275, height="auto",
                      h2("What's near your child's elementary school?"),
                      selectInput("rad", label=strong("Display Radius Around Schools:"), 
                                 choices=c("None", "1/4 mile", "1/2 mile", "1 mile")),
                      p(strong("Select Establishment Type(s):")),
                      checkboxGroupInput("type", label=NULL, selected="Beer, Wine, and Liquor Stores", choices=sort(as.character(unique(unlist(all$type))))),
                      h6(em("Webmap by the", a("Metropolitan Futures Initiative", href="http://mfi.soceco.uci.edu", target="_blank"))
                      )),
                                                  
         absolutePanel(id = "controls", class="panel panel-default", fixed = TRUE,
                  draggable=TRUE, top=110, left=10, right="auto", bottom="auto",
                  width=150, height="auto",
                  p("Data Notes:"),
                  h6("-- Map covers elementary schools in Long Beach and Signal Hill, California"),
                  h6("-- Data are from ReferenceUSA and are current as of 2014."),
                  h6("-- Select as many retail/service types using the checkboxes."),
                  h6("-- PLEASE WAIT until selection changes before clicking more checkboxes! App may need to be refreshed if it is not given sufficient time to 'respond' to selection.")
                                                                
                                                  )
)))



