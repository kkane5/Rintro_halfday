# Web map for displaying proximity of services to elementary schools - Long Beach, CA
# K. Kane, January 2017

library(shiny)
library(leaflet)

all <- read.csv("LBplus1mi_RefUSA_2014.csv", stringsAsFactors = F)
sch <- read.csv("schools.csv")

shinyServer <- function(input, output, session) {
 
  output$myMap <- renderLeaflet({
    leaflet() %>% setView(lng=-118.168754, lat=33.7952, zoom=14) %>% addTiles() 
  })
  
  observe({
    # SELECT LOCATIONS FROM 'all' TO DISPLAY
    locations = all[all$type %in% input$type,]
    # CREATE COLOR SCHEME - map colors to the 'domain' which is the unique list of store types
    pal <- colorFactor(c("red", "blue", "orange", "yellow"), domain = sort(as.character(unique(unlist(all$type)))))
    # MAKE CONDITIONAL FOR RADII AROUND SCHOOLS
    if(input$rad=="1/4 mile"){meters <- 402.25}
    else if(input$rad=="1/2 mile"){meters <- 804.5}
    else if(input$rad=="1 mile"){meters <- 1609}
    else meters <- 0
    # INVOKE USER'S CHANGES TO MAP
    leafletProxy("myMap") %>% clearMarkers() %>% clearControls() %>% clearShapes() %>%
      addMarkers(data=sch, lng=~X, lat=~Y, popup=~CONAME) %>% 
      addCircles(data=sch, lng=~X, lat=~Y, radius = ~meters, 
                 fill=F, weight=5, opacity=1) %>% 
      addCircleMarkers(data=locations, lng=~X, lat=~Y, popup=~CONAME, radius = 7,
                       stroke=T, col="black", weight=2, opacity=1, fill=T,
                       fillCol=~pal(locations$type), fillOpacity=0.5) 
  })
}

