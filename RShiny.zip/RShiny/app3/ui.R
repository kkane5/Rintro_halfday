library(shiny)
library(leaflet)
library(sp)
library(maptools)

# Files must be read in here if ui.R calls something from them (in this case, 'names')
sub <- readShapePoly("SoCal_place_2010_UA")
dfsub <- data.frame(sub)
names = as.character(unique(unlist(dfsub$NAME10)))

# This app uses a tab panel with a custom .css style. The whole UI is within the parentheses following div()
shinyUI(tabPanel("Industries & Employment", div(class="outer", tags$head(includeCSS("styles.css")),
        # Indicates where to put the leaflet (map) output, and for it to fill the page                                                       
        leafletOutput("myMap", width="100%", height="100%"),
        # This is the right-side user input panel 
        absolutePanel(id = "controls", class = "panel panel-default", fixed = TRUE,
                     draggable = TRUE, top = 60, left = "auto", right = 20, bottom = "auto", width = 330, height = "auto",
                     # The drop-down input for zoom-to-city-centroid ('input$cent') and the action button invoking it - input$recenter
                     # note that 'names' comes from shapefile above. 'order' is used to alphabetize. 
                     selectInput("cent", label=strong("Zoom to City:"), selected="Irvine", choices=names[order(names)]),
                     actionButton("recenter", label="Re-center Map"),
                     br(""),
                     radioButtons("year", label=strong("Select Timeframe: "), choices=list("1997", "2014"), selected="2014", inline=T),
                     br(""),
                     radioButtons("topic", label=strong("Select Topic: "), choices=list("Employment", "Specialization"), selected="Employment", inline=T),
                     br(""),
                     selectInput("type", label=strong("Select Category: "), selected="Total", choices = list("", "High Tech", "KIBS", "Creative Class", "Retail", "Industrial", "Total")),
                     actionButton("go", label="Click to Refresh After Changing Selection"),
                     br(""),
                     # This input selection is used only for displaying the city's value. 
                     selectInput("city", label=strong("Select City to Display Value: "), selected="Irvine", choices = names[order(names)]),
                     verbatimTextOutput("data1")
                     ),
        # this is a small left-side panel with some additional info. 
        absolutePanel(id = "controls", class="panel panel-default", fixed = TRUE,
                     draggable=TRUE, top=110, left=10, right="auto", bottom="auto", width=160, height="auto",
                     p("Data Notes:"),
                     h6("-- Please click to refresh after making new selections to ensure correct map and legend are displayed."),
                     h6(textOutput("var_desc")),
                     h6(textOutput("var_desc2")),
                     h6("-- See", a("our website", href="http://mfi.soceco.uci.edu", target="_blank"), "for details.")
                                                               )
))

)


