# Several packages need to be invoked which contain map-related functions
library(shiny)
library(leaflet)
library(sp)
library(maptools)

# Reads in shapefiles, generates a data frame version of it to use for data display 'dfsub' and converts zero values to NA
sub <- readShapePoly("SoCal_place_2010_UA")
dfsub <- data.frame(sub)
dfsub[dfsub==0] = NA  

shinyServer(function(input, output) {
  
  # (1) REACTIVE FUNCTION FOR ZOOM-TO-CITY. Default coords are Irvine.
  # Shapefile has centroid x/y as attributes; user selects place name (NAME10). 
  # Recenter button will invoke location change. 
  center <- reactiveValues(x_coord=-117.7736, y_coord=33.67801)
  observeEvent(input$recenter, {
    center$x_coord = dfsub$x_coord[dfsub$NAME10==input$cent]
    center$y_coord = dfsub$y_coord[dfsub$NAME10==input$cent]
  })
  
  # (2) REACTIVE FUNCTION FOR GRABBING USER INPUT AS 'options$choose'
  options = reactiveValues(choose="Em_all_14")
  observeEvent(input$go, {
    # upon clicking button 'input$go', 'options$choose' becomes the user-selected column name
    type_link = switch(input$type, "Total"="_all_", "KIBS"="_kibs_",
                       "Creative Class"="_crtv_", "Retail"="_ret_", "High Tech"="_tech_", "Industrial"="_ind_")
    options$choose = paste(substr(input$topic,1,2), type_link, substr(input$year,3,4), sep="")
  })
  
  # (3) MAKE THE MAP AS A REACTIVE TO USER INPUTS
  finalMap <- reactive ({
    # turns 'options$choose' into a numeric vector of values, the object 'choice'
    choice = dfsub[,grep(options$choose, colnames(dfsub))]
    # uses a conditional if/else if/else to select color palettes based on 
    # idea is to create object 'pal' based on vector 'choice.' Bin, quantile, and factor are symbology options.
    if(input$topic=="Specialization"){pal <- colorBin("Greens", choice, bins=c(0, 0.33, 0.66, 1, 1.5, 2, 4, 15), na.color="#B0171F")}
    else if(input$topic=="Employment"){pal <- colorQuantile("Blues", choice, na.color="#B0171F", n=5)}
    else {pal <- colorFactor("blue", domain=dfsub$welcome)}
    # Create map. Invoke leaflet command on data object 'sub' to create map object 'm'
    # %>% structure adds components to 'm' such as polygons and legend. 
    m = leaflet(sub) %>%  setView(lng=center$x_coord, lat=center$y_coord , zoom=11) %>% addTiles() %>%
      # addPolygons draws from 'sub,' and fillcolor is controlled by 'pal' object and 'choice' vector
      # popup can be any column in 'sub' data frame. Leading tilde (~) ensures non-failure if no selection exists.
      addPolygons(data=sub, stroke=T, weight=1.1, fillColor = ~pal(choice), color="black", fillOpacity=0.5, 
                  opacity=1, popup=~NAME10) %>%
      # legend takes object 'pal' as argument for color palette (also called pal...), and 'choice' for values.
      addLegend("bottomleft", pal=pal, values=~choice, opacity=0.75, na.label=~paste('No', input$type, 'Businesses', sep=' '),
                title=~paste(input$year, input$type, input$topic, sep=" "))
  })
  
  # (4) PASS THE REACTIVE MAP TO AN OUTPUT OBJECT CALLED 'output$myMap' 
  output$myMap = renderLeaflet(finalMap())

 # (5) GRAB VALUES FOR THE CITY IN 'input$city' AND RENDER VALUE + PERCENTILE TO 'output$data1' 
    output$data1 <- renderPrint({
      paste(round(dfsub[,grep(options$choose, colnames(dfsub))][dfsub$NAME10==input$city],4),
            "(", round(ecdf(dfsub[,grep(options$choose, colnames(dfsub))])(dfsub[,grep(options$choose, colnames(dfsub))][dfsub$NAME10==input$city]),4), "percentile)")
    })
  
  # (6) CREATE TWO OUTPUT OBJECTS BASED ON USER INPUTS WHICH PROVIDE A DESCRIPTION OF USER'S SELECTIONS
  output$var_desc <- renderText({
    data_notes = switch(input$topic,
                        "Employment" = "displays each city's employment based on its percentile, compared to cities region-wide.",
                        "Specialization"= "displays the selected category's location quotient in each city. A value above 1 indicates a high concentration of that industry relative to the whole region. TOTAL cannot be selected.")
    paste("-- ", input$topic, data_notes, sep=" ")  # handy trick makes it look like there are bullet points
  })
  output$var_desc2 <- renderText({
    data_notes = switch(input$type,
                        "High Tech" = "spans several industries and includes tech manufacturing.",
                        "KIBS"= "stands for Knowledge-Intensive Business Services.",
                        "Creative Class" = "employment consists of arts, entertainment, recreation, and information.",
                        "Retail" = "selected.",
                        "Industrial" = "includes manufacturing and utilities.",
                        "Total" = "cannot be selected for SPECIALIZATION")
    paste("-- ", input$type, data_notes, sep=" ")
  })

})
