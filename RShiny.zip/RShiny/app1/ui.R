# Define any variables or read in any files you need here.
n=200
# This is the style of the output page - bootstrapPage - everything in UI should be in parentheses
bootstrapPage(
  # Add arguments in format command(content),
  # this is a UI text display called Header 1 - h1() - many styles are available such as p() for regular text
  h1("Shiny App - Uniform Draws"),
  # First input or 'control widget' - allows user to select number of observations and is referred to as input$n
  numericInput('n', 'Select number of observations:', n),
  # Second input - select from a list of choices - referred to as input$color in server.R
  selectInput('color', label="Select Color", choices=list('grey', 'red', 'blue', 'green'), selected='grey'),
  # one of several UI output commands, e.g. printOutput, textOutput, mapOutput 
  plotOutput('plot')
)