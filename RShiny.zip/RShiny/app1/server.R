# Server's main contribution is to convert inputs to outputs. Everything goes in this bracketed function:
function(input, output) {
  # Creates an output as an R object called 'plot.' 
  # renderPlot function builds some output (a plot, in this case) - renderText, renderPrint, etc. are others
  output$plot <- renderPlot(hist(runif(input$n), main="Histogram of Uniform Distribution", xlab="Value", col=input$color)
  )
}